l_bc = function(xx_p3_bi,yy_p3){

  # #memory allocation
  if(.Platform$OS.type == "windows") withAutoprint({
    memory.size()
    memory.size(TRUE)
    memory.limit()
  })
  memory.limit(size=56000)

  # # vxx <- getValuesFocal(xx, 1, nrow(xx), ngb=w, na.rm=T, pad =T)
  # vyy <- getValuesFocal(yy_p3, 1, nrow(yy_p3), ngb=w, na.rm =T, pad =F)
  # vzz <- getValuesFocal(dem_m1_p1, 1, nrow(dem_m1_p1), ngb=w, na.rm =T, pad =F)
  # vxx <- getValuesFocal(xx_p3_bi, 1, nrow(xx_p3_bi), ngb=w, na.rm =T, pad =F)
  #
  # x = xx_p3_bi[[1]]
  #
  # # plot(basin_p7, add=T)
  # plot(x)
  # ncell = getValues(x)
  # ncell1 = length(ncell)
  # x
  # ncell1
  #
  # f_y1 =list()
  # f_z1 = list()
  # f_fit1 = list()
  # f_fit = list()
  # # f_fit[[1:2]] <- raster(x)
  # # test_ras=list()
  # #
  # # extent(x)=extent(r3)
  # # crs(x) = crs(r3)
  # # fit =rep(NA,nrow(vxx[[1]]))
  # # for (j in 1:432){
  # #   fit =rep(NA,nrow(vxx[[1]]))
  # #   for (k in 1:ncell1){
  # #     y1 = vyy[[j]][k,]
  # #     x1 = vzz[[j]][k,]
  # #     xy = na.omit(data.frame(x = x1, y =y1))
  # #     if (nrow(xy)>4){
  # #       fit[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
  # #     }
  # #     else{
  # #       fit[k] = NA
  # #     }
  # #   }
  # #   f_fit[[j]] <- raster(x)
  # #   values(f_fit[[j]])=fit
  # #   print(j)
  # # }
  #
  #
  # fit1 =rep(NA,nrow(vxx[[1]]))
  # for (j in 1:432){
  #   fit1 =rep(NA,nrow(vxx[[1]]))
  #   for (k in 1:ncell1){
  #     y1 = vxx[[j]][k,]
  #     x1 = vzz[[j]][k,]
  #     xy = na.omit(data.frame(x = x1, y =y1))
  #     if (nrow(xy)>4){
  #       fit1[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
  #     }
  #     else{
  #       fit1[k] = NA
  #     }
  #   }
  #   f_fit1[[j]] <- raster(x)
  #   values(f_fit1[[j]])=fit1
  #   print(j)
  # }
  #
  # # plot(f_fit[[1]])
  # # plot(f_fit1[[1]])
  # # st_lr1_p3_n1_y = stack(f_fit)
  # st_lr1_p3_n1_x = stack(f_fit1)
  #
  # st_lr1_p3_n1_xn = list()
  #
  # st_lr1_p3_n1_x[!is.finite(st_lr1_p3_n1_x)] <- NA
  #
  # # st_lr1_p3_n1_xn = list()
  #
  # st_lr1_p3_n1_xmax1 <- max(st_lr1_p3_n1_x, na.rm=T)
  # st_lr1_p3_n1_xmin1 <- min(st_lr1_p3_n1_x, na.rm=T)
  #
  # st_lr1_p3_n1_xn=list()
  #
  # for (i in 1:432){
  #   st_lr1_p3_n1_xn[[i]] = (st_lr1_p3_n1_x[[i]]-st_lr1_p3_n1_xmin1)/(st_lr1_p3_n1_xmax1-st_lr1_p3_n1_xmin1)
  # }
  #
  # st_lr1_p3_n1_xn = stack(st_lr1_p3_n1_xn)

  jun = seq(6, 240, 12)
  jul = seq(7, 240, 12)
  aug = seq(8, 240, 12)
  sep = seq(9, 240, 12)
  jan = seq(1, 240, 12)
  oct = seq(10, 240, 12)
  nov = seq(11, 240, 12)
  dec = seq(12, 240, 12)
  feb = seq(2, 240, 12)
  mar = seq(3, 240, 12)
  apl = seq(4, 240, 12)
  may = seq(5, 240, 12)

  # #lapse rate cal
  # lp_y_jan = st_lr1_p3_n1_y[[jan]]
  # lp_y_feb = st_lr1_p3_n1_y[[feb]]
  # lp_y_mar = st_lr1_p3_n1_y[[mar]]
  # lp_y_apl = st_lr1_p3_n1_y[[apl]]
  # lp_y_may = st_lr1_p3_n1_y[[may]]
  # lp_y_jun = st_lr1_p3_n1_y[[jun]]
  # lp_y_jul = st_lr1_p3_n1_y[[jul]]
  # lp_y_aug = st_lr1_p3_n1_y[[aug]]
  # lp_y_sep = st_lr1_p3_n1_y[[sep]]
  # lp_y_oct = st_lr1_p3_n1_y[[oct]]
  # lp_y_nov = st_lr1_p3_n1_y[[nov]]
  # lp_y_dec = st_lr1_p3_n1_y[[dec]]
  #
  # lp_y_jan1 <- calc(lp_y_jan, fun = sd)
  # lp_y_feb1 <- calc(lp_y_feb, fun = sd)
  # lp_y_mar1 <- calc(lp_y_mar, fun = sd)
  # lp_y_apl1 <- calc(lp_y_apl, fun = sd)
  # lp_y_may1 <- calc(lp_y_may, fun = sd)
  # lp_y_jun1 <- calc(lp_y_jun, fun = sd)
  # lp_y_jul1 <- calc(lp_y_jul, fun = sd)
  # lp_y_aug1 <- calc(lp_y_aug, fun = sd)
  # lp_y_sep1 <- calc(lp_y_sep, fun = sd)
  # lp_y_oct1 <- calc(lp_y_oct, fun = sd)
  # lp_y_nov1 <- calc(lp_y_nov, fun = sd)
  # lp_y_dec1 <- calc(lp_y_dec, fun = sd)
  #
  # lp_x_jan = st_lr1_p3_n1_x[[jan]]
  # lp_x_feb = st_lr1_p3_n1_x[[feb]]
  # lp_x_mar = st_lr1_p3_n1_x[[mar]]
  # lp_x_apl = st_lr1_p3_n1_x[[apl]]
  # lp_x_may = st_lr1_p3_n1_x[[may]]
  # lp_x_jun = st_lr1_p3_n1_x[[jun]]
  # lp_x_jul = st_lr1_p3_n1_x[[jul]]
  # lp_x_aug = st_lr1_p3_n1_x[[aug]]
  # lp_x_sep = st_lr1_p3_n1_x[[sep]]
  # lp_x_oct = st_lr1_p3_n1_x[[oct]]
  # lp_x_nov = st_lr1_p3_n1_x[[nov]]
  # lp_x_dec = st_lr1_p3_n1_x[[dec]]
  #
  # lp_x_jan1 <- calc(lp_x_jan, fun = sd)
  # lp_x_feb1 <- calc(lp_x_feb, fun = sd)
  # lp_x_mar1 <- calc(lp_x_mar, fun = sd)
  # lp_x_apl1 <- calc(lp_x_apl, fun = sd)
  # lp_x_may1 <- calc(lp_x_may, fun = sd)
  # lp_x_jun1 <- calc(lp_x_jun, fun = sd)
  # lp_x_jul1 <- calc(lp_x_jul, fun = sd)
  # lp_x_aug1 <- calc(lp_x_aug, fun = sd)
  # lp_x_sep1 <- calc(lp_x_sep, fun = sd)
  # lp_x_oct1 <- calc(lp_x_oct, fun = sd)
  # lp_x_nov1 <- calc(lp_x_nov, fun = sd)
  # lp_x_dec1 <- calc(lp_x_dec, fun = sd)
  #
  # jan_lr = lp_y_jan1/lp_x_jan1
  # feb_lr = lp_y_feb1/lp_x_feb1
  # mar_lr = lp_y_mar1/lp_x_mar1
  # apl_lr = lp_y_apl1/lp_x_apl1
  # may_lr = lp_y_may1/lp_x_may1
  # jun_lr = lp_y_jun1/lp_x_jun1
  # jul_lr = lp_y_jul1/lp_x_jul1
  # aug_lr = lp_y_aug1/lp_x_aug1
  # sep_lr = lp_y_sep1/lp_x_sep1
  # oct_lr = lp_y_oct1/lp_x_oct1
  # nov_lr = lp_y_nov1/lp_x_nov1
  # dec_lr = lp_y_dec1/lp_x_dec1

  # plot(lp_x_jan[[2]])

  # gcm2_rain_lr = stack(jan_lr,feb_lr,mar_lr,apl_lr, may_lr, jun_lr,jul_lr,aug_lr,sep_lr,oct_lr,nov_lr,dec_lr)
  # gcm6_1_lr_temp_nan

  # save(gcm2_rain_lr,
  #      file = "F:/OneDrive/AIT/students/2021_May/Vishal/R/nan1/gcm6_2_lr_rain_nan.RData")

  xx_p3_lr = list();
  # plot(lp_y_jan1/lp_x_jan1)
  # plot(basin_p8, add=T)

  # for (i in 1:432){
  #   #241:432
  #   print(i)
  #   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  #   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
  #
  #   if(i%%12 == 1){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_jan1/lp_x_jan1)
  #
  #   } else if(i%%12 == 2){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_feb1/lp_x_feb1)
  #
  #   } else if(i%%12 == 3){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_mar1/lp_x_mar1)
  #
  #   } else if(i%%12 == 4){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_apl1/lp_x_apl1)
  #
  #   } else if(i%%12 == 5){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_may1/lp_x_may1)
  #
  #   } else if(i%%12 == 6){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_jun1/lp_x_jun1)
  #
  #   } else if(i%%12 == 7){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_jul1/lp_x_jul1)
  #
  #   } else if(i%%12 == 8){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_aug1/lp_x_aug1)
  #
  #   } else if(i%%12 == 9){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_sep1/lp_x_sep1)
  #
  #   } else if(i%%12 == 10){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_oct1/lp_x_oct1)
  #
  #   } else if(i%%12 == 11){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_nov1/lp_x_nov1)
  #
  #   } else if(i%%12 == 0){
  #     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_dec1/lp_x_dec1)
  #
  #   }  else {
  #     NULL
  #   }
  #
  # }
  #
  # xx_p3_lr = stack(xx_p3_lr)

  ratio= xx_p3_bi

  nlayers = 20

  coeffun <- function(x) {
    r <- rep(NA, nlayers)
    obs <- x[1:nlayers]
    x1 <- x[21:40]
    x2 <- x[41:60]
    # Remove NA values before model
    x.nona <- which(!is.na(obs) & !is.na(x1) & !is.na(x2))
    # If more than 2 points proceed to lm
    if (length(x.nona) > 2) {
      m <- NA
      try(m <- lm(obs[x.nona] ~ x1[x.nona] + x2[x.nona]))
      # If model worked, calculate residuals
      if (is(m)[1] == "lm") {
        r[x.nona] <- m$coefficients[1:3]
      } else {
        # alternate value to find where model did not work
        r[x.nona] <- -1e32
      }
    }
    return(r)
  }

  coeffun_nonl <- function(x) {
    r <- rep(NA, nlayers)
    obs <- x[1:nlayers]
    x1 <- x[21:40]
    # x2 <- x[73:108]
    # Remove NA values before model
    x.nona <- which(!is.na(obs) & !is.na(x1))
    # If more than 2 points proceed to lm
    if (length(x.nona) > 2) {
      m <- NA
      try(m <- lm(obs[x.nona] ~ x1[x.nona]))
      # If model worked, calculate residuals
      if (is(m)[1] == "lm") {
        r[x.nona] <- m$coefficients[1:2]
      } else {
        # alternate value to find where model did not work
        r[x.nona] <- -1e32
      }
    }
    return(r)
  }

  coeffun_nonl1 <- function(x) {
    r <- rep(NA, nlayers)
    obs <- x[1:nlayers]
    x1 <- x[21:40]
    # x2 <- x[73:108]
    # Remove NA values before model
    x.nona <- which(!is.na(obs) & !is.na(x1))
    # If more than 2 points proceed to lm
    if (length(x.nona) > 2) {
      m <- NA
      try(m <- lm(I(obs[x.nona]-0) ~ 0+x1[x.nona]))
      # If model worked, calculate residuals
      if (is(m)[1] == "lm") {
        r[x.nona] <- m$coefficients[1]
      } else {
        # alternate value to find where model did not work
        r[x.nona] <- -1e32
      }
    }
    return(r)
  }


  sch_jan3 = stack(yy_p3[[jan[1:20]]],ratio[[jan[1:20]]])
  sch_feb3 = stack(yy_p3[[feb[1:20]]],ratio[[feb[1:20]]])
  sch_mar3 = stack(yy_p3[[mar[1:20]]],ratio[[mar[1:20]]])
  sch_apl3 = stack(yy_p3[[apl[1:20]]],ratio[[apl[1:20]]])
  sch_may3 = stack(yy_p3[[may[1:20]]],ratio[[may[1:20]]])
  sch_jun3 = stack(yy_p3[[jun[1:20]]],ratio[[jun[1:20]]])
  sch_jul3 = stack(yy_p3[[jul[1:20]]],ratio[[jul[1:20]]])
  sch_aug3 = stack(yy_p3[[aug[1:20]]],ratio[[aug[1:20]]])
  sch_sep3 = stack(yy_p3[[sep[1:20]]],ratio[[sep[1:20]]])
  sch_oct3 = stack(yy_p3[[oct[1:20]]],ratio[[oct[1:20]]])
  sch_nov3 = stack(yy_p3[[nov[1:20]]],ratio[[nov[1:20]]])
  sch_dec3 = stack(yy_p3[[dec[1:20]]],ratio[[dec[1:20]]])


  #------------parameter estimation----------
  par_jan3 <- calc(sch_jan3, coeffun_nonl)
  par_feb3 <- calc(sch_feb3, coeffun_nonl)
  par_mar3 <- calc(sch_mar3, coeffun_nonl)
  par_apl3 <- calc(sch_apl3, coeffun_nonl)
  par_may3 <- calc(sch_may3, coeffun_nonl)
  par_jun3 <- calc(sch_jun3, coeffun_nonl)
  par_jul3 <- calc(sch_jul3, coeffun_nonl)
  par_aug3 <- calc(sch_aug3, coeffun_nonl)
  par_sep3 <- calc(sch_sep3, coeffun_nonl)
  par_oct3 <- calc(sch_oct3, coeffun_nonl)
  par_nov3 <- calc(sch_nov3, coeffun_nonl)
  par_dec3 <- calc(sch_dec3, coeffun_nonl)


  #-----------------
  # plot(par_jan3[[2]])
  #
  param3p=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
                 par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])
  #
  # param2p=stack(par_jan3_nonl[[1:2]],par_feb3_nonl[[1:2]],par_mar3_nonl[[1:2]],par_apl3_nonl[[1:2]],par_may3_nonl[[1:2]],par_jun3_nonl[[1:2]],
  #               par_jul3_nonl[[1:2]],par_aug3_nonl[[1:2]],par_sep3_nonl[[1:2]],par_oct3_nonl[[1:2]],par_nov3_nonl[[1:2]],par_dec3_nonl[[1:2]])


  # save(par_jan3, par_feb3, par_mar3,
  #      par_apl3,par_may3,par_jun3,
  #      par_jul3,par_aug3,par_sep3,
  #      par_oct3,par_nov3,par_dec3,
  #      file = "F:/OneDrive/AIT/students/2021_May/Vishal/R/nan1/gcm6_2_pr_params_nan.RData")

  # save(par_jan3_nonl, par_feb3_nonl, par_mar3_nonl,
  #      par_apl3_nonl,par_may3_nonl,par_jun3_nonl,
  #      par_jul3_nonl,par_aug3_nonl,par_sep3_nonl,
  #      par_oct3_nonl,par_nov3_nonl,par_dec3_nonl,
  #      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1_nonl.RData")
  #

  # plot(par_jan3[[2]])


  pred_rcm1_3p = list();

  for (i in 1:432){
    #241:432
    print(i)
    # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
    # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')

    if(i%%12 == 1){
      pred_rcm1_3p[[i]] = (par_jan3[[2]] * ratio[[i]])+par_jan3[[1]]

    } else if(i%%12 == 2){
      pred_rcm1_3p[[i]] = (par_feb3[[2]] * ratio[[i]])+par_feb3[[1]]

    } else if(i%%12 == 3){
      pred_rcm1_3p[[i]] = (par_mar3[[2]] * ratio[[i]])+par_mar3[[1]]

    } else if(i%%12 == 4){
      pred_rcm1_3p[[i]] = (par_apl3[[2]] * ratio[[i]])+par_apl3[[1]]

    } else if(i%%12 == 5){
      pred_rcm1_3p[[i]] = (par_may3[[2]] * ratio[[i]])+par_may3[[1]]

    } else if(i%%12 == 6){
      pred_rcm1_3p[[i]] = (par_jun3[[2]] * ratio[[i]])+par_jun3[[1]]

    } else if(i%%12 == 7){
      pred_rcm1_3p[[i]] = (par_jul3[[2]] * ratio[[i]])+par_jul3[[1]]

    } else if(i%%12 == 8){
      pred_rcm1_3p[[i]] = (par_aug3[[2]] * ratio[[i]])+par_aug3[[1]]

    } else if(i%%12 == 9){
      pred_rcm1_3p[[i]] = (par_sep3[[2]] * ratio[[i]])+par_sep3[[1]]

    } else if(i%%12 == 10){
      pred_rcm1_3p[[i]] = (par_oct3[[2]] * ratio[[i]])+par_oct3[[1]]

    } else if(i%%12 == 11){
      pred_rcm1_3p[[i]] = (par_nov3[[2]] * ratio[[i]])+par_nov3[[1]]

    } else if(i%%12 == 0){
      pred_rcm1_3p[[i]] = (par_dec3[[2]] * ratio[[i]])+par_dec3[[1]]

    }  else {
      NULL
    }

  }

  pred_rcm1_3p = stack(pred_rcm1_3p)

  # pred_rcm1_3p
  # ratio
  # param3p

  out_l = stack(pred_rcm1_3p,param3p)

  return(out_l)

}

