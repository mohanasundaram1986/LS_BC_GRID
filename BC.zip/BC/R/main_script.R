library(raster)
library(rgdal)
library(sf)
library(dplyr)
library(spData)
library(gstat)
library(tmap)
library(maptools)
library(readxl)
library(raster)
library(ggplot2)
library(rasterVis)
library(gridExtra)
library(ncdf4)

library(raster)
library(gstat)
library(sp)

#study basin
basin1 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/test.shp")
dem = raster('F:/OneDrive/AIT/papers/rainfall_biascorrection/data/cmip6_gcm/dem/elev.0.25-deg.nc')

#dem
dem_c <- crop(dem,basin1)
dem_m = mask(dem_c, basin1)
# dem_m_p1 =dem_m

#moving window
w=c(5,5)


# basin2 <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_p1_n2.shp")
# basin1 <- readOGR("E:/Cloud/OneDrive/AIT/papers/rainfall_biascorrection/gis/ma_s3.shp")
# basin2 <- readOGR("C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/gis/mon_asia3_seg_sw.shp")

#observation
p1 <- "F:/OneDrive/AIT/papers/rainfall_biascorrection/data/aphrodite/data/"
R1 <- list.files(p1, pattern = "nc$")

ap_rain <- raster::stack(file.path(p1, R1), varname = "precip")

#gcm data
p2 <- "F:/OneDrive/AIT/papers/rainfall_biascorrection/data/cmip6_gcm/monthly/MIROC6/pr_hist/"
R2 <- list.files(p2, pattern = "nc$")

gcm1_rain_hist <- raster::stack(file.path(p2, R2), varname = "pr")

#crop to study area
s1_crop <- crop(ap_rain,basin1)
s1_ap = s1_crop[[6941:20089]]
s1_ap1 = s1_ap

#get the date from the names of the layers and extract the month
idx_1_a <- seq(as.Date('1970-01-01'), as.Date('2005-12-31'), 'day')
idx_2_a <- seq(as.Date('1970-01-01'), as.Date('2005-12-31'), 'month')
idx_3_a <- seq(1,12)

names(s1_ap1)=idx_1_a

indices_a <- format(as.Date(names(s1_ap1), format = "X%Y.%m.%d"), format = "%y.%m")
indices_a <- as.numeric(indices_a)

#sum layers
month_ap<- stackApply(s1_ap1, indices_a, fun = sum)
names(month_ap) <- idx_2_a

#mean_month
indices1_a <- format(as.Date(names(month_ap), format = "X%Y.%m.%d"), format = "%m")
indices1_a <- as.numeric(indices1_a)

month_ap1<- stackApply(month_ap, indices1_a, fun = mean)
names(month_ap1) = idx_3_a

indices2_a = names(month_ap1)
# indices2 = as.numeric(indices2)

#yearly rainfall
year_ap = sum(month_ap1)

#GCM monthly rain
s1_gcm1 = gcm1_rain_hist[[241:672]]*86400*30
#
# month_gcm1_r_p1 =list();
# month_ap_r_p1 = list();
month_gcm1_r = list();
dem_m_r = resample(dem_m, month_ap[[1]],'bilinear')
dem_m1_p1 = stack(replicate(432,dem_m_r))

# dem_m1_p1= list();
# plot(month_ap_c_p1[[1]])
for (i in 1:432){
  #241:432
  print(i)
  # dem_m1_p1[[i]]=resample(dem_m_p1,dem_m_p1,'bilinear')
  # month_ap_r_p1[[i]] = resample(month_ap[[i]],dem_m_p1,'bilinear')
  # month_gcm1_r_p1[[i]] = resample(s1_gcm1[[i]],month_ap[[1]],'ngb')
  month_gcm1_r[[i]] = resample(s1_gcm1[[i]],month_ap[[1]],'bilinear')

}

yy_p3 = list()
xx_p3 = list()
yy_p3 = stack(month_ap)
xx_p3 = stack(month_gcm1_r)

# vxx <- getValuesFocal(xx, 1, nrow(xx), ngb=w, na.rm=T, pad =T)
vyy <- getValuesFocal(yy_p3, 1, nrow(yy_p3), ngb=w, na.rm =T, pad =F)
vzz <- getValuesFocal(dem_m1_p1, 1, nrow(dem_m1_p1), ngb=w, na.rm =T, pad =F)
vxx <- getValuesFocal(xx_p3, 1, nrow(xx_p3), ngb=w, na.rm =T, pad =F)

x = xx_p3[[1]]

# plot(basin_p7, add=T)
plot(x)
ncell = getValues(x)
ncell1 = length(ncell)
x
ncell1



f_y1 =list()
f_z1 = list()
f_fit1 = list()
f_fit = list()
# f_fit[[1:2]] <- raster(x)
# test_ras=list()
#
# extent(x)=extent(r3)
# crs(x) = crs(r3)
# fit =rep(NA,nrow(vxx[[1]]))
# for (j in 1:432){
#   fit =rep(NA,nrow(vxx[[1]]))
#   for (k in 1:ncell1){
#     y1 = vyy[[j]][k,]
#     x1 = vzz[[j]][k,]
#     xy = na.omit(data.frame(x = x1, y =y1))
#     if (nrow(xy)>4){
#       fit[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
#     }
#     else{
#       fit[k] = NA
#     }
#   }
#   f_fit[[j]] <- raster(x)
#   values(f_fit[[j]])=fit
#   print(j)
# }


fit1 =rep(NA,nrow(vxx[[1]]))
for (j in 1:432){
  fit1 =rep(NA,nrow(vxx[[1]]))
  for (k in 1:ncell1){
    y1 = vxx[[j]][k,]
    x1 = vzz[[j]][k,]
    xy = na.omit(data.frame(x = x1, y =y1))
    if (nrow(xy)>4){
      fit1[k] =coefficients(lm(as.numeric(xy$y)~as.numeric(xy$x)))[2]
    }
    else{
      fit1[k] = NA
    }
  }
  f_fit1[[j]] <- raster(x)
  values(f_fit1[[j]])=fit1
  print(j)
}

# plot(f_fit[[1]])
# plot(f_fit1[[1]])
# st_lr1_p3_n1_y = stack(f_fit)
st_lr1_p3_n1_x = stack(f_fit1)

st_lr1_p3_n1_x[!is.finite(st_lr1_p3_n1_x)] <- NA

st_lr1_p3_n1_xn = list()

st_lr1_p3_n1_xmax1 <- max(st_lr1_p3_n1_x, na.rm=T)
st_lr1_p3_n1_xmin1 <- min(st_lr1_p3_n1_x, na.rm=T)

st_lr1_p3_n1_xn=list()

for (i in 1:432){
  st_lr1_p3_n1_xn[[i]] = (st_lr1_p3_n1_x[[i]]-st_lr1_p3_n1_xmin1)/(st_lr1_p3_n1_xmax1-st_lr1_p3_n1_xmin1)
}

st_lr1_p3_n1_xn = stack(st_lr1_p3_n1_xn)

jun = seq(6, 240, 12)
jul = seq(7, 240, 12)
aug = seq(8, 240, 12)
sep = seq(9, 240, 12)
jan = seq(1, 240, 12)
oct = seq(10, 240, 12)
nov = seq(11, 240, 12)
dec = seq(12, 240, 12)
feb = seq(2, 240, 12)
mar = seq(3, 240, 12)
apl = seq(4, 240, 12)
may = seq(5, 240, 12)

# #lapse rate cal
# lp_y_jan = st_lr1_p3_n1_y[[jan]]
# lp_y_feb = st_lr1_p3_n1_y[[feb]]
# lp_y_mar = st_lr1_p3_n1_y[[mar]]
# lp_y_apl = st_lr1_p3_n1_y[[apl]]
# lp_y_may = st_lr1_p3_n1_y[[may]]
# lp_y_jun = st_lr1_p3_n1_y[[jun]]
# lp_y_jul = st_lr1_p3_n1_y[[jul]]
# lp_y_aug = st_lr1_p3_n1_y[[aug]]
# lp_y_sep = st_lr1_p3_n1_y[[sep]]
# lp_y_oct = st_lr1_p3_n1_y[[oct]]
# lp_y_nov = st_lr1_p3_n1_y[[nov]]
# lp_y_dec = st_lr1_p3_n1_y[[dec]]
#
# lp_y_jan1 <- calc(lp_y_jan, fun = sd)
# lp_y_feb1 <- calc(lp_y_feb, fun = sd)
# lp_y_mar1 <- calc(lp_y_mar, fun = sd)
# lp_y_apl1 <- calc(lp_y_apl, fun = sd)
# lp_y_may1 <- calc(lp_y_may, fun = sd)
# lp_y_jun1 <- calc(lp_y_jun, fun = sd)
# lp_y_jul1 <- calc(lp_y_jul, fun = sd)
# lp_y_aug1 <- calc(lp_y_aug, fun = sd)
# lp_y_sep1 <- calc(lp_y_sep, fun = sd)
# lp_y_oct1 <- calc(lp_y_oct, fun = sd)
# lp_y_nov1 <- calc(lp_y_nov, fun = sd)
# lp_y_dec1 <- calc(lp_y_dec, fun = sd)
#
# lp_x_jan = st_lr1_p3_n1_x[[jan]]
# lp_x_feb = st_lr1_p3_n1_x[[feb]]
# lp_x_mar = st_lr1_p3_n1_x[[mar]]
# lp_x_apl = st_lr1_p3_n1_x[[apl]]
# lp_x_may = st_lr1_p3_n1_x[[may]]
# lp_x_jun = st_lr1_p3_n1_x[[jun]]
# lp_x_jul = st_lr1_p3_n1_x[[jul]]
# lp_x_aug = st_lr1_p3_n1_x[[aug]]
# lp_x_sep = st_lr1_p3_n1_x[[sep]]
# lp_x_oct = st_lr1_p3_n1_x[[oct]]
# lp_x_nov = st_lr1_p3_n1_x[[nov]]
# lp_x_dec = st_lr1_p3_n1_x[[dec]]
#
# lp_x_jan1 <- calc(lp_x_jan, fun = sd)
# lp_x_feb1 <- calc(lp_x_feb, fun = sd)
# lp_x_mar1 <- calc(lp_x_mar, fun = sd)
# lp_x_apl1 <- calc(lp_x_apl, fun = sd)
# lp_x_may1 <- calc(lp_x_may, fun = sd)
# lp_x_jun1 <- calc(lp_x_jun, fun = sd)
# lp_x_jul1 <- calc(lp_x_jul, fun = sd)
# lp_x_aug1 <- calc(lp_x_aug, fun = sd)
# lp_x_sep1 <- calc(lp_x_sep, fun = sd)
# lp_x_oct1 <- calc(lp_x_oct, fun = sd)
# lp_x_nov1 <- calc(lp_x_nov, fun = sd)
# lp_x_dec1 <- calc(lp_x_dec, fun = sd)
#
# jan_lr = lp_y_jan1/lp_x_jan1
# feb_lr = lp_y_feb1/lp_x_feb1
# mar_lr = lp_y_mar1/lp_x_mar1
# apl_lr = lp_y_apl1/lp_x_apl1
# may_lr = lp_y_may1/lp_x_may1
# jun_lr = lp_y_jun1/lp_x_jun1
# jul_lr = lp_y_jul1/lp_x_jul1
# aug_lr = lp_y_aug1/lp_x_aug1
# sep_lr = lp_y_sep1/lp_x_sep1
# oct_lr = lp_y_oct1/lp_x_oct1
# nov_lr = lp_y_nov1/lp_x_nov1
# dec_lr = lp_y_dec1/lp_x_dec1

# plot(lp_x_jan[[2]])

# gcm2_rain_lr = stack(jan_lr,feb_lr,mar_lr,apl_lr, may_lr, jun_lr,jul_lr,aug_lr,sep_lr,oct_lr,nov_lr,dec_lr)
# gcm6_1_lr_temp_nan

# save(gcm2_rain_lr,
#      file = "F:/OneDrive/AIT/students/2021_May/Vishal/R/nan1/gcm6_2_lr_rain_nan.RData")

xx_p3_lr = list();
# plot(lp_y_jan1/lp_x_jan1)
# plot(basin_p8, add=T)

# for (i in 1:432){
#   #241:432
#   print(i)
#   # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
#   # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')
#
#   if(i%%12 == 1){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_jan1/lp_x_jan1)
#
#   } else if(i%%12 == 2){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_feb1/lp_x_feb1)
#
#   } else if(i%%12 == 3){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_mar1/lp_x_mar1)
#
#   } else if(i%%12 == 4){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_apl1/lp_x_apl1)
#
#   } else if(i%%12 == 5){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_may1/lp_x_may1)
#
#   } else if(i%%12 == 6){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_jun1/lp_x_jun1)
#
#   } else if(i%%12 == 7){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_jul1/lp_x_jul1)
#
#   } else if(i%%12 == 8){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_aug1/lp_x_aug1)
#
#   } else if(i%%12 == 9){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_sep1/lp_x_sep1)
#
#   } else if(i%%12 == 10){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_oct1/lp_x_oct1)
#
#   } else if(i%%12 == 11){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_nov1/lp_x_nov1)
#
#   } else if(i%%12 == 0){
#     xx_p3_lr[[i]] = xx_p3_bi[[i]] * (lp_y_dec1/lp_x_dec1)
#
#   }  else {
#     NULL
#   }
#
# }
#
# xx_p3_lr = stack(xx_p3_lr)

ratio= st_lr1_p3_n1_xn * xx_p3

nlayers = 20

coeffun <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[21:40]
  x2 <- x[41:60]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1) & !is.na(x2))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(obs[x.nona] ~ x1[x.nona] + x2[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1:3]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}

coeffun_nonl <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[21:40]
  # x2 <- x[73:108]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(obs[x.nona] ~ x1[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1:2]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}

coeffun_nonl1 <- function(x) {
  r <- rep(NA, nlayers)
  obs <- x[1:nlayers]
  x1 <- x[21:40]
  # x2 <- x[73:108]
  # Remove NA values before model
  x.nona <- which(!is.na(obs) & !is.na(x1))
  # If more than 2 points proceed to lm
  if (length(x.nona) > 2) {
    m <- NA
    try(m <- lm(I(obs[x.nona]-0) ~ 0+x1[x.nona]))
    # If model worked, calculate residuals
    if (is(m)[1] == "lm") {
      r[x.nona] <- m$coefficients[1]
    } else {
      # alternate value to find where model did not work
      r[x.nona] <- -1e32
    }
  }
  return(r)
}


sch_jan3 = stack(yy_p3[[jan[1:20]]],ratio[[jan[1:20]]])
sch_feb3 = stack(yy_p3[[feb[1:20]]],ratio[[feb[1:20]]])
sch_mar3 = stack(yy_p3[[mar[1:20]]],ratio[[mar[1:20]]])
sch_apl3 = stack(yy_p3[[apl[1:20]]],ratio[[apl[1:20]]])
sch_may3 = stack(yy_p3[[may[1:20]]],ratio[[may[1:20]]])
sch_jun3 = stack(yy_p3[[jun[1:20]]],ratio[[jun[1:20]]])
sch_jul3 = stack(yy_p3[[jul[1:20]]],ratio[[jul[1:20]]])
sch_aug3 = stack(yy_p3[[aug[1:20]]],ratio[[aug[1:20]]])
sch_sep3 = stack(yy_p3[[sep[1:20]]],ratio[[sep[1:20]]])
sch_oct3 = stack(yy_p3[[oct[1:20]]],ratio[[oct[1:20]]])
sch_nov3 = stack(yy_p3[[nov[1:20]]],ratio[[nov[1:20]]])
sch_dec3 = stack(yy_p3[[dec[1:20]]],ratio[[dec[1:20]]])


#------------parameter estimation----------
par_jan3 <- calc(sch_jan3, coeffun_nonl)
par_feb3 <- calc(sch_feb3, coeffun_nonl)
par_mar3 <- calc(sch_mar3, coeffun_nonl)
par_apl3 <- calc(sch_apl3, coeffun_nonl)
par_may3 <- calc(sch_may3, coeffun_nonl)
par_jun3 <- calc(sch_jun3, coeffun_nonl)
par_jul3 <- calc(sch_jul3, coeffun_nonl)
par_aug3 <- calc(sch_aug3, coeffun_nonl)
par_sep3 <- calc(sch_sep3, coeffun_nonl)
par_oct3 <- calc(sch_oct3, coeffun_nonl)
par_nov3 <- calc(sch_nov3, coeffun_nonl)
par_dec3 <- calc(sch_dec3, coeffun_nonl)


#-----------------
# plot(par_jan3[[2]])
#
param3p=stack(par_jan3[[1:2]],par_feb3[[1:2]],par_mar3[[1:2]],par_apl3[[1:2]],par_may3[[1:2]],par_jun3[[1:2]],
              par_jul3[[1:2]],par_aug3[[1:2]],par_sep3[[1:2]],par_oct3[[1:2]],par_nov3[[1:2]],par_dec3[[1:2]])
#
# param2p=stack(par_jan3_nonl[[1:2]],par_feb3_nonl[[1:2]],par_mar3_nonl[[1:2]],par_apl3_nonl[[1:2]],par_may3_nonl[[1:2]],par_jun3_nonl[[1:2]],
#               par_jul3_nonl[[1:2]],par_aug3_nonl[[1:2]],par_sep3_nonl[[1:2]],par_oct3_nonl[[1:2]],par_nov3_nonl[[1:2]],par_dec3_nonl[[1:2]])


# save(par_jan3, par_feb3, par_mar3,
#      par_apl3,par_may3,par_jun3,
#      par_jul3,par_aug3,par_sep3,
#      par_oct3,par_nov3,par_dec3,
#      file = "F:/OneDrive/AIT/students/2021_May/Vishal/R/nan1/gcm6_2_pr_params_nan.RData")

# save(par_jan3_nonl, par_feb3_nonl, par_mar3_nonl,
#      par_apl3_nonl,par_may3_nonl,par_jun3_nonl,
#      par_jul3_nonl,par_aug3_nonl,par_sep3_nonl,
#      par_oct3_nonl,par_nov3_nonl,par_dec3_nonl,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1_nonl.RData")
#

# plot(par_jan3[[2]])


pred_rcm1_3p = list();

for (i in 1:432){
  #241:432
  print(i)
  # rcmv_r[[i]] = resample(month_rcm[[i]],r3,'bilinear')
  # apv_r[[i]] = resample(month_ap[[i]],r3,'bilinear')

  if(i%%12 == 1){
    pred_rcm1_3p[[i]] = (par_jan3[[2]] * ratio[[i]])+par_jan3[[1]]

  } else if(i%%12 == 2){
    pred_rcm1_3p[[i]] = (par_feb3[[2]] * ratio[[i]])+par_feb3[[1]]

  } else if(i%%12 == 3){
    pred_rcm1_3p[[i]] = (par_mar3[[2]] * ratio[[i]])+par_mar3[[1]]

  } else if(i%%12 == 4){
    pred_rcm1_3p[[i]] = (par_apl3[[2]] * ratio[[i]])+par_apl3[[1]]

  } else if(i%%12 == 5){
    pred_rcm1_3p[[i]] = (par_may3[[2]] * ratio[[i]])+par_may3[[1]]

  } else if(i%%12 == 6){
    pred_rcm1_3p[[i]] = (par_jun3[[2]] * ratio[[i]])+par_jun3[[1]]

  } else if(i%%12 == 7){
    pred_rcm1_3p[[i]] = (par_jul3[[2]] * ratio[[i]])+par_jul3[[1]]

  } else if(i%%12 == 8){
    pred_rcm1_3p[[i]] = (par_aug3[[2]] * ratio[[i]])+par_aug3[[1]]

  } else if(i%%12 == 9){
    pred_rcm1_3p[[i]] = (par_sep3[[2]] * ratio[[i]])+par_sep3[[1]]

  } else if(i%%12 == 10){
    pred_rcm1_3p[[i]] = (par_oct3[[2]] * ratio[[i]])+par_oct3[[1]]

  } else if(i%%12 == 11){
    pred_rcm1_3p[[i]] = (par_nov3[[2]] * ratio[[i]])+par_nov3[[1]]

  } else if(i%%12 == 0){
    pred_rcm1_3p[[i]] = (par_dec3[[2]] * ratio[[i]])+par_dec3[[1]]

  }  else {
    NULL
  }

}

pred_rcm1_3p = stack(pred_rcm1_3p)

bc_ls1 = ls_bc(xx_p3,yy_p3)
bc_lr1 = lr_bc(xx_p3,yy_p3,dem_m1_p1,w)
bc_l1 = l_bc(xx_p3,yy_p3)



#extract
#project points
point_basin_p <- readOGR("F:/OneDrive/AIT/papers/rainfall_biascorrection/gis/test_pt2.shp")
# coordinates(point_basin_p)=~lon+lat
point_p=point_basin_p
# proj4string(point_p) = utm47Q
# extent(point_p) = ap_5km

pointdf1 <- as.data.frame(point_p)
xy_p <- pointdf1[,c(2,3)]
# xy_1 =xy[1:36,]
# xy_1
# coordinates(xy(xy_1) = utm47Q
# extent(xy_1) = ap_5km


# s1_ac1 = resample(s1_ac,s1_ap,'ngb')
plot(s1_rcm_all[[219]])
plot(point_basin_p,add=T)


jun = seq(6, 240, 12)
jul = seq(7, 240, 12)
aug = seq(8, 240, 12)
sep = seq(9, 240, 12)
jan = seq(1, 240, 12)
oct = seq(10, 240, 12)
nov = seq(11, 240, 12)
dec = seq(12, 240, 12)
feb = seq(2, 240, 12)
mar = seq(3, 240, 12)
apl = seq(4, 240, 12)
may = seq(5, 240, 12)


bc_lr1_1 = bc_lr1[[433:864]]
bc_lr1_y = bc_lr1[[865:1296]]
bc_lr1_x = bc_lr1[[1297:1728]]



normalize_stack <- function (x) {
  ls <- list()
  for (i in 1:dim(x)[3]) {
    ls[[i]] <- (x - min(x))/(max(x)-min(x))
  }
  return(stack(ls))
}
min <- function (x) {
  min(extract(x, 1:ncell(x)))
}

max <- function (x) {
  max(extract(x, 1:ncell(x)))
}

normalize <- function (x) {
  return((x - min(x))/(max(x)-min(x)))
}
xx_p3n = normalize_stack(xx_p3)

norm1 <- function(x) {min(x)}
xx_p3max1 <- calc(xx_p3, function(x){max(x)})
xx_p3min1 <- calc(xx_p3, function(x){min(x)})

xx_p3norm=list()

for (i in 1:432){
  xx_p3norm[[i]] = (xx_p3[[i]]-xx_p3min1)/(xx_p3max1-xx_p3min1)
}

plot(xx_p3norm[[1]])
function(x){max(x)}

xx_p3_min=stackApply(xx_p3, indices = rep(1, nlayers(xx_p3)), fun = max, na.rm =T)
# xx_p3_min = min(xx_p3, na.rm=T)
# Create a test RasterBrick
r <- raster(ncol=10, nrow=10)
r[]=1:ncell(r)
b <- brick(r,r,r,r,r,r)

stackApply(b, indices = rep(1, nlayers(b)), fun = max)

calc(b, function(x){max(x)})

maxStack <- calc(b, function(x) max(x, na.rm = TRUE))

if(.Platform$OS.type == "windows") withAutoprint({
  memory.size()
  memory.size(TRUE)
  memory.limit()
})
memory.limit(size=56000)

min(xx_p3)


rasValue_ac=extract(yy_p3[[dec]], xy_p[1,1])
rasValue_gcm = extract(xx_p3[[dec]],xy_p[1,1])
rasValue_lrx = extract(bc_lr1_x[[dec]],xy_p[1,1])
rasValue_lry = extract(bc_lr1_y[[dec]],xy_p[1,1])
rasValue_lryn = (rasValue_lry-min(rasValue_lry))/((max(rasValue_lry)-min(rasValue_lry)))
rasValue_lrxn = (rasValue_lrx-min(rasValue_lrx))/((max(rasValue_lrx)-min(rasValue_lrx)))

plot(rasValue_gcm,rasValue_ac)
plot(rasValue_ac,rasValue_lrx)
plot(rasValue_ac,rasValue_lry)
plot(rasValue_lryn,rasValue_lrxn)
plot((rasValue_lrxn*rasValue_gcm),rasValue_ac)

a=rasValue_ac
b=((rasValue_lryn/rasValue_lrxn))*rasValue_gcm

data.frame(c(a),c(b))

plot(a[1:13],b[1:13])
a = data.frame(((rasValue_lryn/rasValue_lrxn))*rasValue_gcm,rasValue_ac)
a=rasValue_ac[1,1:7305]

r_ac1 = rasValue_ac[1:36,1:7305]

ras=extract(ap_5km, xy_p[,])
r_ap=ras[1,1:7305]


r_ap1 = ras[1:36,1:7305]


# dem extrac
dem1 = dem
dem2=crop(dem1, point_p)

plot(dem2)
plot(point_p, add=T)
# r2 <- focal(dem2, w=matrix(1, nc=11, nr=11), na.rm = TRUE, fun = mean, pad = TRUE);

r3 = aggregate(dem2,10)

spts <- rasterToPoints(r3, spatial = TRUE)
proj4string(spts)

ppts = as.data.frame(spts)

#range of elevation
p_500 = ppts[ppts[1]<500,]
p_1000 = ppts[ppts[1]>500 & ppts[1]<1000,]
p_2000 = ppts[ppts[1]>1000,]

plot(r2)
plot(r3)
plot(p_500[,2:3], add=T)
# a <- focal(x, w=matrix(1/9, nc=3, nr=3))
demV = extract(r3, ppts[2:3])
demV_500 = extract(r3, p_500[2:3])
demV_1000 = extract(r3, p_1000[2:3])
demV_2000 = extract(r3, p_2000[2:3])


#Evaluation
pred_rcm1_2p_s = bc_ls1[[241:432]]
pred_rcm1_3p_s = pred_rcm1_3p[[241:432]]
pred_rc1_l_s = bc_l1[[241:432]]



ls_corr_xx = bc_lr1[[433:864]]

bc_ls2 = ls_bc(ls_corr_xx,yy_p3)

pred_rcm1_2p_s = bc_ls1[[241:432]]
pred_rcm1_3p_s = bc_ls2[[241:432]]

# pred_rcm1_2p_s1 = stack(pred_rcm1_2p_s[[jan[1:16]]])
# pred_rcm1_3p_s1 = stack(pred_rcm1_3p_s[[jan[1:16]]])


pred_rcm1_3p_s[pred_rcm1_3p_s<0] = 0

yy_p3_v = yy_p3[[241:432]]
# xx_p3_bias_v = xx_p3_bias[[241:432]]

# yy_p3_v1 = yy_p3_v[[jan[1:16]]]
# xx_p3_bias_v1 = xx_p3_bias_v[[jan[1:16]]]


# stat_ras_bl_p1_n1 = stack(yy_p3_v, xx_p3_bias_v)
stat_ras_2p_p1_n1 = stack(yy_p3_v, pred_rcm1_2p_s)
stat_ras_3p_p1_n1= stack(yy_p3_v, pred_rcm1_3p_s)
stat_ras_bl_p1_n1 = stack(yy_p3_v, pred_rc1_l_s)


# stat_ras_bl_p1_n1 = stack(yy_p3_v1, xx_p3_bias_v1)
# stat_ras_2p_p1_n1 = stack(yy_p3_v1, pred_rcm1_2p_s1)
# stat_ras_3p_p1_n1= stack(yy_p3_v1, pred_rcm1_3p_s1)


plot(stat_ras_3p_p1_n1[[243]])

plot(stat_ras_2p_p1_n1[[243]])
# save(stat_ras_bl_p1_n1,stat_ras_2p_p1_n1,stat_ras_3p_p1_n1,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_val1_n1.RData")
#
# save(par_jan3_nonl, par_feb3_nonl, par_mar3_nonl,
#      par_apl3_nonl,par_may3_nonl,par_jun3_nonl,
#      par_jul3_nonl,par_aug3_nonl,par_sep3_nonl,
#      par_oct3_nonl,par_nov3_nonl,par_dec3_nonl,
#      file = "C:/Users/ezhil/OneDrive/AIT/papers/rainfall_biascorrection/R/environment/gcm6_1_p1_params_n1_nonl.RData")

fun_mae_nolr <- function(x) {mean(abs((x[1:192] - x[193:384])))}
sd_mae_nolr <- calc(stat_ras_2p_p1_n1, fun_mae_nolr)

plot(sd_mae_nolr)

#rmse
fun_sqrt_nolr <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
sd_sqrt_nolr <- calc(stat_ras_2p_p1_n1, fun_sqrt_nolr)

plot(sd_sqrt_nolr)

#r2
rsq <- function (x) cor(x[1:192], x[193:384]) ^ 2
sd_r2_nolr <- calc(stat_ras_2p_p1_n1, rsq)
plot(sd_r2_nolr)

# function(x, y) summary(lm(y~x))$r.squared
# fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
# sd_r2 <- calc(stat_ras, fun_r2)

# function(x, y) summary(lm(y~x))$r.squared
# fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
# sd_r2 <- calc(stat_ras, fun_r2)
#
# plot(sd_r2)

fun_mae <- function(x) {mean(abs((x[1:192] - x[193:384])))}
sd_mae <- calc(stat_ras_3p_p1_n1, fun_mae)

plot(sd_mae)

#rmse
fun_sqrt <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
sd_sqrt <- calc(stat_ras_3p_p1_n1, fun_sqrt)

plot(sd_sqrt)


rsq_3p <- function (x) cor(x[1:192], x[193:384]) ^ 2
sd_r2 <- calc(stat_ras_3p_p1_n1, rsq_3p)
plot(sd_r2)


#bilinear
fun_mae_bl <- function(x) {mean(abs((x[1:192] - x[193:384])))}
sd_mae_bl <- calc(stat_ras_bl_p1_n1, fun_mae_bl)

plot(sd_mae_bl)

#rmse
fun_sqrt_bl <- function(x) {sqrt(mean((x[1:192] - x[193:384])^2))}
sd_sqrt_bl <- calc(stat_ras_bl_p1_n1, fun_sqrt_bl)

rsq_bl <- function (x) cor(x[1:192], x[193:384]) ^ 2
bl_r2 <- calc(stat_ras_bl_p1_n1, rsq_bl)
plot(bl_r2)



plot(sd_sqrt_bl)

a = (sd_r2-sd_r2_nolr)/sd_r2_nolr
a[a<0.0]=NA

plot(a)


plot(((sd_sqrt-sd_sqrt_nolr)/sd_sqrt_nolr))
plot(((sd_r2-sd_r2_nolr)/sd_r2_nolr))

plot(((sd_mae_bl-sd_mae_nolr)/sd_mae_nolr))
plot(((sd_r2-bl_r2)/bl_r2))


# plot(dem_m_p1[[1]])
aa = ((sd_sqrt-sd_sqrt_nolr)/sd_sqrt_nolr)

aa[aa>-0.05]=NA

plot(aa)


#r2

# function(x, y) summary(lm(y~x))$r.squared
fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
sd_r2 <- calc(stat_ras_2p, fun_r2)




plot(rcm_f85[[3250]])
plot(month_rcm_f85_r[[350]])


#future projection
rasValue_ac=extract(yy_p3, xy_p[1,1])
rasValue_gcm = extract(xx_p3,xy_p[1,1])

o = rasValue_ac[1:241]
p = rasValue_gcm[1:241]
s = rasValue_gcm[242:432]
o1 = rasValue_ac[242:432]


#' @title Empirical Quantile Mapping method for bias correction
#' @description Implementation of Empirical Quantile Mapping method for bias correction
#' @param o A vector (e.g. station data) containing the observed climate data for the training period
#' @param p A vector containing the simulated climate by the model for the training period.
#' @param s A vector containing the simulated climate for the variable used in \code{p}, but considering the test period.
#' @param precip Logical for precipitation data. If TRUE Adjusts precipitation
#' frequency in 'x' (prediction) to the observed frequency in 'y'. This is a preprocess to bias correct
#' precipitation data following Themeßl et al. (2012). To adjust the frequency,
#' parameter \code{pr.threshold} is used (see below).
#' @param pr.threshold The minimum value that is considered as a non-zero precipitation. Ignored when
#' \code{precip = FALSE}. See details in function \code{biasCorrection}.
#' @param n.quantiles Integer indicating the number of quantiles to be considered when method = "eqm". Default is NULL,
#' that considers all quantiles, i.e. \code{n.quantiles = length(p)}.
#' @param extrapolation Character indicating the extrapolation method to be applied to correct values in
#' \code{"s"} that are out of the range of \code{"p"}. Extrapolation is applied only to the \code{"eqm"} method,
#' thus, this argument is ignored if other bias correction method is selected.
#' @keywords internal
#' @importFrom stats approxfun ecdf quantile
#' @author S. Herrera and M. Iturbi
#'


eqm <- function(o, p, s, precip, pr.threshold=1, n.quantiles, extrapolation){
  if (precip == TRUE) {
    threshold <- pr.threshold
    if (any(!is.na(o))) {
      params <-  adjustPrecipFreq(o, p, threshold)
      p <- params$p
      nP <- params$nP
      Pth <- params$Pth
    } else {
      nP = NULL
    }
    smap <- rep(NA, length(s))
    if (any(!is.na(p)) & any(!is.na(o))) {
      if (length(which(p > Pth)) > 0) {
        noRain <- which(s <= Pth & !is.na(s))
        rain <- which(s > Pth & !is.na(s))
        drizzle <- which(s > Pth  & s  <= min(p[which(p > Pth)], na.rm = TRUE) & !is.na(s))
        if (length(rain) > 0) {
          eFrc <- tryCatch({ecdf(s[rain])}, error = function(err) {stop("There are not precipitation days in newdata for the step length selected in one or more locations. Try to enlarge the window step")})
          if (is.null(n.quantiles)) n.quantiles <- length(p)
          bins <- n.quantiles
          qo <- quantile(o[which(o > threshold & !is.na(o))], prob = seq(1/bins,1 - 1/bins,1/bins), na.rm = T)
          qp <- quantile(p[which(p > Pth)], prob = seq(1/bins,1 - 1/bins,1/bins), na.rm = T)
          p2o <- tryCatch({approxfun(qp, qo, method = "linear")}, error = function(err) {NA})
          smap <- s
          smap[rain] <- if (suppressWarnings(!is.na(p2o))) {
            p2o(s[rain])
          }else{
            s[rain] <- NA
          }
          # Linear extrapolation was discarded due to lack of robustness
          if (extrapolation == "constant") {
            smap[rain][which(s[rain] > max(qp, na.rm = TRUE))] <- s[rain][which(s[rain] > max(qp, na.rm = TRUE))] + (qo[length(qo)] - qp[length(qo)])
            smap[rain][which(s[rain] < min(qp, na.rm = TRUE))] <- s[rain][which(s[rain] < min(qp, na.rm = TRUE))] + (qo[1] - qp[1])
          } else {
            smap[rain][which(s[rain] > max(qp, na.rm = TRUE))] <- qo[length(qo)]
            smap[rain][which(s[rain] < min(qp, na.rm = TRUE))] <- qo[1]
          }
        }else{
          smap <- rep(0, length(s))
          warning("There are not precipitation days in newdata for the step length selected in one or more locations. Consider the possibility of enlarging the window step")
        }
        if (length(drizzle) > 0) {
          smap[drizzle] <- quantile(s[which(s > min(p[which(p > Pth)], na.rm = TRUE) & !is.na(s))], probs = eFrc(s[drizzle]), na.rm = TRUE, type = 4)
        }
        smap[noRain] <- 0
      } else { ## For dry series
        smap <- s
        warning('No rainy days in the prediction. Bias correction is not applied')
      }
    }
  } else {
    if (all(is.na(o))) {
      smap <- rep(NA, length(s))
    } else if (all(is.na(p))) {
      smap <- rep(NA, length(s))
    }else if (any(!is.na(p)) & any(!is.na(o))) {
      if (is.null(n.quantiles)) n.quantiles <- length(p)
      bins <- n.quantiles
      qo <- quantile(o, prob = seq(1/bins,1 - 1/bins,1/bins), na.rm = TRUE)
      qp <- quantile(p, prob = seq(1/bins,1 - 1/bins,1/bins), na.rm = TRUE)
      p2o <- approxfun(qp, qo, method = "linear")
      smap <- p2o(s)
      if (extrapolation == "constant") {
        smap[which(s > max(qp, na.rm = TRUE))] <- s[which(s > max(qp, na.rm = TRUE))] + (qo[length(qo)] - qp[length(qo)])
        smap[which(s < min(qp, na.rm = TRUE))] <- s[which(s < min(qp, na.rm = TRUE))] + (qo[1] - qp[1])
      } else {
        smap[which(s > max(qp, na.rm = TRUE))] <- qo[length(qo)]
        smap[which(s < min(qp, na.rm = TRUE))] <- qo[1]
      }
    }
  }
  return(smap)
}

qmap = eqm(o,p,s,precip=FALSE,,n.quantiles=length(p),"eqm")

fun_r2 <- function(x) {summary(lm(x[433:864]~x[1:432]))$r.squared}
sd_r2 <- calc(stat_ras_2p, fun=eqm)

funSPEI3 <- function(x, scale=3, na.rm=TRUE,...) as.numeric((spei(x, scale=scale, na.rm=na.rm, ...))$fitted)


r<-gcm6_en_s1_p1[[1]] #my raster taken from a first layer of a stack
rlon<-rlat<-r #copy r to rlon and rlat rasters [1]][1]which will contain the longitude and latitude
xy<-xyFromCell(r,1:length(r)) #matrix of logitudes (x) and latitudes(y)
rlon[]<-xy[,1] #raster of longitudes
rlat[]<-xy[,2] #raster of latitides
par(mfrow=c(1,2))
image(rlon,main="longitudes")
image(rlat,main="latitudes")


th <- function(Tave, lat) {
  as.vector(SPEI::thornthwaite(as.vector(Tave), lat, na.rm=T))
}

eqm_grid <- function(o,p,s,precip=FALSE,pr.threshold=1,n.quantiles=241,"eqm")
  {as.vector(eqm(o,p,s,precip=FALSE,,n.quantiles=length(p),"eqm"))}

obs = yy_p3[[1:241]]
gc = xx_p3[[1:241]]
pred = xx_p3[[242:432]]

out1 = overlay(obs, gc, pred, precip=FALSE,pr.threshold =1,n.quantiles=241,"eqm", fun=eqm_grid)


# r7 <- overlay(r1, r2, r3, r4, fun=function(a,b,c,d){return(a*b+c*d)} )

r7 <- overlay(obs, gc, pred, fun= Vectorize(eqm(o,p,s,precip=FALSE,,n.quantiles=241,"eqm")))

# lat <- init(raster(tm), "y")

## now run overlay with Vectorize in the function call
out <- overlay(gcm6_en_s1_p1, rlat, fun = Vectorize(th))


plot(o1,qmap)

data.frame(o1,qmap)

plot(bc_ls[[1]])


library(climateR)
#
biasCorrection(
  y,
  x,
  newdata = NULL,
  precipitation = FALSE,
  method = c("delta", "scaling", "eqm", "pqm", "gpqm", "loci", "dqm", "qdm", "isimip3"),
  cross.val = c("none", "loo", "kfold"),
  folds = NULL,
  consecutive = TRUE,
  window = NULL,
  scaling.type = c("additive", "multiplicative"),
  fitdistr.args = list(densfun = "normal"),
  wet.threshold = 1,
  n.quantiles = NULL,
  extrapolation = c("none", "constant"),
  theta = c(0.95, 0.05),
  detrend = TRUE,
  isimip3.args = NULL,
  join.members = FALSE,
  return.raw = FALSE,
  interpGrid.args = list(),
  parallel = FALSE,
  max.ncores = 16,
  ncores = NULL
)
install.packages("remotes")
remotes::install_github("SantanderMetGroup/downscaleR")

require(climate4R.datasets)
data("EOBS_Iberia_pr")
data("CORDEX_Iberia_pr")
y <- EOBS_Iberia_pr
x <- CORDEX_Iberia_pr
#

library(qmap)
r <- raster(ncol=20, nrow=20)
obs <- stack(lapply(1:100, function(x) setValues(r, runif(ncell(r)))))  #observed data
mod <- stack(lapply(1:100, function(x) setValues(r, runif(ncell(r)))))*2  #modelled data (i want this unbiased)

# obs1 = yy_p3[[1:240]]
# obs2 = yy_p3[[241:432]]
# mod1 = xx_p3_bi[[1:240]]
# mod2 = xx_p3_bi[[241:432]]
#
# qm.fit <- fitQmap((t(obs1[])), (t(mod1[])), method="QUANT",qstep=0.1)
#
# bias_corrected_qm <- doQmap(t(mod2[]), qm.fit, type="linear")
#
# bias_corrected_qm_arr <- as.array(t(bias_corrected_qm))

# #reshape array
# dim(bias_corrected_qm_arr) <- c(43,125,192)
#
# # convert to rasterbrick
# mod_Bcorrected_qm <- setValues(brick(mod1,values=FALSE),bias_corrected_qm_arr)
#
# plot(mod_Bcorrected_qm[[8]])
# plot(obs2[[8]])

